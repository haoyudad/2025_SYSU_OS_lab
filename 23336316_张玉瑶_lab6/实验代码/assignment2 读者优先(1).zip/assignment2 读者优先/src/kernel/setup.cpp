#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#include "sync.h"

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

Semaphore semaphore; //be a rw_mutex
Semaphore counter;// be a counter
int cheese_burger=0;
int reader_counter=0;


void a_mother(void *arg) // be a writer
{
  while(1){
    
    int delay =0xfffffff;

    printf("mother %d: try to make cheese burger, there are %d cheese burger now\n",programManager.running->pid, cheese_burger);
    
    semaphore.P();
    // make 10 cheese_burger
    cheese_burger += 10;

    printf("mother %d: now I have made %d cheese buger now\n ",programManager.running->pid, cheese_burger);
    
    while (delay)
        --delay;
    // done

    printf("mother %d: Oh, Jesus! There are %d cheese burgers\n",programManager.running->pid, cheese_burger);
    semaphore.V();
 //   for(int i=0;i<10000;i++){
  //          for(int j=0;j<1000;j++){}
  //  }
  }  
}

void a_naughty_boy(void *arg) //be a reader
{    
    //读者进入，counter++
  while(1){ 
    

    counter.P(); //counter上锁
    reader_counter++;//读者++
    if(reader_counter==1){
        semaphore.P();
    }//第一个读者上互斥锁阻塞写者进入
    counter.V();
    
    printf("boy %d : Look what I found! There are %d burgers!\n",programManager.running->pid,cheese_burger);
   
    int delay = 0xfffffff;

    while (delay)
        --delay;
    // done
   
    //读者离开
    counter.P(); //counter上锁
    reader_counter--;//读者--
    
    if(reader_counter==0){
    
        for(int i=0;i<10000;i++){
            for(int j=0;j<1000;j++){}
    }
        semaphore.V();
    }//没有读者时释放锁让写者进
    counter.V();
    for(int i=0;i<10000;i++){
            for(int j=0;j<1000;j++){}
    }
  }  
 
}

void first_thread(void *arg)
{
    // 第1个线程不可以返回
    stdio.moveCursor(0);
    for (int i = 0; i < 25 * 80; ++i)
    {
        stdio.print(' ');
    }
    stdio.moveCursor(0);

    //cheese_burger = 0;
    semaphore.initialize(1);
    counter.initialize(1); 
    for(int i=0; i<10; i++){//十个儿子十个reader
        programManager.executeThread(a_naughty_boy, nullptr, "reader thread", 1);
    }
    
    
    programManager.executeThread(a_mother, nullptr, "writer thread", 1);
    
    for(int i=0; i<5; i++){//再来5个儿子5个reader
        programManager.executeThread(a_naughty_boy, nullptr, "reader thread", 1);
    }
    interruptManager.enableTimeInterrupt(); // 开启时钟中断
    interruptManager.enableInterrupt(); // 允许中断发生

    while (true) {
    // 不退出，保持运行状态，让其他线程被调度
    }

}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    // 创建第一个线程
    int pid = programManager.executeThread(first_thread, nullptr, "first thread", 1);
    if (pid == -1)
    {
        printf("can not execute thread\n");
        asm_halt();
    }

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    firstThread->status = RUNNING;
    programManager.readyPrograms.pop_front();
    programManager.running = firstThread;
    asm_switch_thread(0, firstThread);

    asm_halt();
}
